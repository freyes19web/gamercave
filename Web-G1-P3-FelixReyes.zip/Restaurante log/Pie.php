			<section id='ContenPie'>
				<footer id='Pie'>					
					<!--Espacio para Social Media-->
					<section class='SocialMedia'>
						<span>Cr&eacute;ditos</span>						
						<section class='SocialIcons'>
							<span>
								Sitio con fines educativos.<b>Valent&iacute;n S&aacute;nchez.</b>
							</span>
						</section>
					</section>
					<!--Espacio para Social Media-->
					<section class='SocialMedia'>
						<span>Agradecimientos</span>						
						<section class='SocialIcons'>
							<a href='#'> <img src='images/icons/Valentec.png' title='Valentec' alt='W3schools.com'> </a>
							<a href='#'> <img src='images/icons/UTECO.png' title='UTECO' alt='UTECO'> </a>
							<a href='#'> <img src='images/icons/ITLA.png' title='ITLA' alt='ITLA'> </a>
							<a href='#'> <img src='images/icons/Multimedia.png' title='Multimedia' alt='Multimedia'> </a>
						</section>
					</section>
					<!--Espacio para Social Media-->
					<section class='SocialMedia'>
						<span>Ayuda</span>						
						<section class='SocialIcons'>
							<a href='#'> <img src='images/icons/efects.png' alt='W3schools.com'> </a>
							<a href='#'> <img src='images/icons/slide.png' alt='HTML5 | W3schools.com'> </a>
							<a href='#'> <img src='images/icons/RWD.png' alt='CSS3 | W3schools.com'> </a>
							<a href='#'> <img src='images/icons/RDW.png' alt='RDW | W3schools.com'> </a>
						</section>
					</section>
					
					<!--Espacio para Social Media-->
					<section class='SocialMedia'>
						<span>Web | Derechos Reservados</span>						
						<section class='SocialIcons'>
							<a href='#'> <img src='images/web.png' alt='W3schools.com'> </a>
						</section>
					</section>
				</footer>
			</section>
		</section>
	</body>